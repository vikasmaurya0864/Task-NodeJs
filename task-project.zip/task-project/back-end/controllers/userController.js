const userService = require('../services/userService');

exports.createUsers = async (req, res) => {
    const data = req.body;
    const response = await userService.createUser(data);
    if (response.result) {
        res.status(201).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}

exports.getAllUsers = async (req, res) => {
    const response = await userService.findAllUsers();
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(404).send({ result: response.message })
    }

}

exports.getUserById = async (req, res) => {
    const userId = req.params.id;
    const response = await userService.getUserById(userId);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(404).send({ result: response.message })
    }
}

exports.updateUser = async (req, res) => {
    const userId = req.params.id;
    const data = req.body;
    const response = await userService.updateOneUser(userId, data);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}

exports.restoreUser = async (req, res) => {
    const userId = req.params.id;
    const response = await userService.restoreUserData(userId);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }

}

exports.deleteUser = async (req, res) => {
    const userId = req.params.id;
    const response = await userService.deleteUserData(userId);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}


exports.createRecruiter = async (req,res) => {
    const data = req.body;
    const response = await userService.createRecruiter(data);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}