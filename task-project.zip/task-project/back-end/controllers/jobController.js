const jobService = require('../services/jobService');

exports.createJob = async (req, res) => {
    const data = req.body;
    req.body.recruiter_id = req.userDetails.user_id;
    const result = await jobService.createJob(data);
    if (result.result) {
        res.send({ status: 201, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });
    }
}

exports.getJob = async (req, res) => {
    const { offset, limit } = req.query;
    const result = await jobService.getJob(offset, limit);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.updateJob = async (req, res) => {
    const JobId = req.params.id;
    const data = req.body;
    const result = await jobService.updateJob(JobId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.deleteJob = async (req, res) => {
    const JobId = req.params.id;
    const result = await jobService.deleteJob(JobId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });

    }
}

