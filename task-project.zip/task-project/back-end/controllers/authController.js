const authService = require('../services/authService');


exports.login = async (req, res) => {
    const { email, password } = req.body;
    const response = await authService.userLogin(email, password);
    if (response.token) {
        res.status(200).send({ result: response.token })
    }
    else {
        res.status(404).send({ result: response.message })
    }
}

exports.forgotPassword = async (req, res) => {
    const email = req.body.email;
    const response = await authService.forgetPassword(email);
    if (response.result && response.userId) {
        res.status(200).send({ result: response.result, userId: response.userId });
    }
    else {
        res.status(400).send({ result: response.message })
    }
}

exports.verifyOtp = async (req, res) => {
    const userId = req.params.id;
    const otp = req.body.otp;
    const response = await authService.verifyOtp(userId, otp);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}

exports.resetPassword = async (req, res) => {
    const userId = req.params.id;
    const { password, confirmPassword } = req.body;
    const response = await authService.resetUserPasswd(userId, password, confirmPassword);
    if (response.result) {
        res.status(201).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}

exports.logOut = async (req, res) => {
    const userId = req.userDetails.user_id;
    const token = req.header("Authorization");
    const response = await authService.user_logOut(userId, token);
    if (response.result) {
        res.status(200).send({ result: response.result })
    }
    else {
        res.status(400).send({ result: response.message })
    }
}