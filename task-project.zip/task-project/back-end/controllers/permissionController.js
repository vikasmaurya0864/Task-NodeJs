const permissionService = require('../services/permissionService');

exports.createPermission = async (req, res) => {
    const data = req.body;
    const result = await permissionService.createPermission(data);
    if (result.result) {
        res.send({ status: 201, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });
    }
}

exports.getPermission = async (req, res) => {
    const result = await permissionService.getPermission();
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.updatePermission = async (req, res) => {
    const permissionId = req.params.id;
    const data = req.body;
    const result = await permissionService.updatePermission(permissionId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.deletePermission = async (req, res) => {
    const permissionId = req.params.id;
    const result = await permissionService.deletePermission(permissionId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });

    }
}
