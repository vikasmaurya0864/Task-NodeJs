const roleService = require('../services/roleService');

exports.createRole = async (req, res) => {
    const data = req.body;
    const result = await roleService.createRole(data);
    if (result.result) {
        res.send({ data: result.result });
    }
    else {
        res.send({ data: result.message });
    }
}

exports.getRole = async (req, res) => {
    const result = await roleService.getRole();
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.updateRole = async (req, res) => {
    const roleId = req.params.id;
    const data = req.body;
    const result = await roleService.updateRole(roleId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.deleteRole = async (req,res) => {
    const roleId = req.params.id;
    const result = await roleService.deleteRole(roleId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });

    }
}

