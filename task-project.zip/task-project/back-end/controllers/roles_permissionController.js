const roles_permissionService = require('../services/roles_permissionService');

exports.createRoles_permission = async (req, res) => {
    const data = req.body;
    const result = await roles_permissionService.createRoles_permission(data);
    if (result.result) {
        res.send({ status: 201, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });
    }
}

exports.getRoles_permission = async (req, res) => {
    const result = await roles_permissionService.getRoles_permission();
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.updateRoles_permission = async (req, res) => {
    const roleId = req.params.id;
    const data = req.body;
    const result = await roles_permissionService.updateRoles_permission(roleId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.deleteRoles_permission = async (req,res) => {
    const roleId = req.params.id;
    const result = await roles_permissionService.deleteRoles_permission(roleId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });

    }
}