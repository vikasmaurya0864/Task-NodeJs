const adminService = require('../services/adminService');



exports.getUserList = async (req, res) => {
    const roleId = req.params.id;
    const { offset, limit } = req.query;
    const result = await adminService.getCandidate(roleId, offset, limit);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.getJobs = async (req, res) => {
    const { offset, limit } = req.query;
    const result = await adminService.getJob(offset, limit);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.updateRecruiter = async (req, res) => {
    const userId = req.params.id;
    const data = req.body;
    const result = await adminService.updateRecruiter(userId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.exportsUsers = async (req, res) => {
    const userId = req.params.id;
    const result = await adminService.exportUser(userId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.exportCandidate = async (req,res) => {
    const userId = req.params.id;
    const result = await adminService.exportCandidate(userId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}