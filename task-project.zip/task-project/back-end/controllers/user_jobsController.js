const user_jobService = require('../services/user_jobsService');

exports.createUser_jobs = async (req, res) => {
    const data = req.body;
    req.body.user_id = req.userDetails.user_id;
    req.body.email = req.userDetails.email;
    req.body.name = req.userDetails.user_name;
    const result = await user_jobService.createUser_jobs(data);
    if (result.result) {
        res.send({ status: 201, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });
    }
}

exports.getUser_jobs = async (req, res) => {
    const jobId = req.params.id;
    const { offset, limit } = req.query;
    const result = await user_jobService.getUser_jobs(jobId, offset, limit);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });
    }
}

exports.getByCandidate = async (req, res) => {
    const { offset, limit } = req.query;
    const userId = req.userDetails.user_id;
    const result = await user_jobService.getByCandidate(userId, offset, limit);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.updateUser_jobs = async (req, res) => {
    const roleId = req.params.id;
    const data = req.body;
    const result = await user_jobService.updateUser_jobs(roleId, data);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 404, data: result.message });

    }
}

exports.deleteUser_jobs = async (req, res) => {
    const roleId = req.params.id;
    const result = await user_jobService.deleteUser_jobs(roleId);
    if (result.result) {
        res.send({ status: 200, data: result.result });
    }
    else {
        res.send({ status: 400, data: result.message });

    }
}