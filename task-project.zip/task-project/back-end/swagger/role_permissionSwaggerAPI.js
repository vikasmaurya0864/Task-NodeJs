// add-role
/**
 * @swagger
 * /api/role_permission/:
 *  post:
 *    tags:
 *      - Role_permission
 *    summary: API use for adding role_permission..
 *    security: 
 *      - bearerAuth: []
 *    consumes:
 *      - application/json
 *    parameters:
 *      - name: body
 *        in: body
 *        required: true
 *        schema:
 *          type: object
 *          required: [ role_id, permission_id ]
 *          properties:
 *            role_id:
 *              type: Number
 *              description: role_id for role_permission
 *              example: 5
 *            permission_id:
 *              type: Number
 *              description: role for permission
 *              example: 8
 *    responses:
 *      '201':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// get-all-permission

/**
 * @swagger
 * /api/role_permission/:
 *  get:
 *    tags:
 *      - User_jobs
 *    summary: API use for getting all role_permission..
 *    security: 
 *      - bearerAuth: []
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// get-role-by-id

/**
 * @swagger
 * /api/role_permission/{id}:
 *  get:
 *    tags:
 *      - User_jobs
 *    summary: API use for getting  role_permission by id..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// update-by-id

/**
 * @swagger
 * /api/role_permission/{id}:
 *  put:
 *    tags:
 *      - User_jobs
 *    summary: API use for updating role_permission..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    - name: body
 *      in: body
 *      required: true
 *      schema:
 *        type: object
 *        required: [ role_id, permission_id ]
 *        properties:
 *          role_id:
 *            type: Number
 *            description: add role_id for role_permission
 *            example: updateUser
 *          permission_id:
 *            type: Number
 *            description: job_id for permission_id
 *            example: This API is for update role_permission.
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// delete-permission-by-id

/**
 * @swagger
 * /api/role_permission/{id}:
 *  delete:
 *    tags:
 *      - User_jobs
 *    summary: API use for deleting  role_permission..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */
