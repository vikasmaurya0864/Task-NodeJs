// add-role
/**
 * @swagger
 * /api/user_jobs/:
 *  post:
 *    tags:
 *      - User_jobs
 *    summary: API use for adding user_jobs..
 *    security: 
 *      - bearerAuth: []
 *    consumes:
 *      - application/json
 *    parameters:
 *      - name: body
 *        in: body
 *        required: true
 *        schema:
 *          type: object
 *          required: [ user_id, job_id ]
 *          properties:
 *            user_id:
 *              type: Number
 *              description: action for permission
 *              example: addUser
 *            job_id:
 *              type: Number
 *              description: description for permission
 *              example: This API is for admin to add new editor.
 *    responses:
 *      '201':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// get-all-permission

/**
 * @swagger
 * /api/user_jobs/:
 *  get:
 *    tags:
 *      - User_jobs
 *    summary: API use for getting all user_jobs..
 *    security: 
 *      - bearerAuth: []
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// get-role-by-id

/**
 * @swagger
 * /api/user_jobs/{id}:
 *  get:
 *    tags:
 *      - User_jobs
 *    summary: API use for getting  user_jobs by id..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// update-by-id

/**
 * @swagger
 * /api/user_jobs/{id}:
 *  put:
 *    tags:
 *      - User_jobs
 *    summary: API use for updating user_jobs..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    - name: body
 *      in: body
 *      required: true
 *      schema:
 *        type: object
 *        required: [ user_id, job_id ]
 *        properties:
 *          user_id:
 *            type: Number
 *            description: add user_id for user_jobs
 *            example: updateUser
 *          job_id:
 *            type: Number
 *            description: job_id for user_jobs
 *            example: This API is for update user_jobs.
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */

// delete-permission-by-id

/**
 * @swagger
 * /api/user_jobs/{id}:
 *  delete:
 *    tags:
 *      - User_jobs
 *    summary: API use for deleting  User_jobs..
 *    security: 
 *      - bearerAuth: []
 *    parameters:
 *    - name: "id"
 *      in: "path"
 *      description: "Id of user to find"
 *      required: true
 *      type: "string"
 *    responses:
 *      '200':
 *        description: A successful response
 *      '404':
 *         description: Product
 *         schema:
 *           type: object
 *           description: not found
 *           properties:
 *             message:
 *               title: message
 *               type: string
 *               example: not found
 */
