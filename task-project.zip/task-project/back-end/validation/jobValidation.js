const { body, param } = require('express-validator');


// create-role
exports.createJob = [
    body('title').notEmpty().withMessage('title must be specified.')
    .isLength({ min: 5, max: 20 })
    .withMessage("title must be minimum 5 chars & maximum 20 chars.")
    .trim(),
    body('description').notEmpty().withMessage('description must be specified.')
    .isLength({ min: 10, max: 150 })
    .withMessage("description must be minimum 10 chars & maximum 50 chars.")
    .trim(),
];
