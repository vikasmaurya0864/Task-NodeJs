const { body, param } = require('express-validator');

exports.createUser = [
    body('name').notEmpty().withMessage('name is required').isLength({ min: 3, max: 50 })
        .withMessage('name must be minimum 3 chars and maximum 50 chars')
        .matches(/^[a-zA-Z ]+$/)
        .withMessage('name must contain alphabets and spaces and not symbol and special characters.')
        .trim(),
    body('email').notEmpty().withMessage('email is required').isLength({ min: 10, max: 50 })
        .withMessage('email must be minimum 10 chars and maximum 50 chars').isEmail().trim(),
    body('password').notEmpty().withMessage('password is required').isLength({ min: 8, max: 20 })
        .withMessage('password must be minimum 8 chars and maximum 20 chars.')
        .trim()
        .matches(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/)
        .withMessage('password must contain one upperCase, one lowerCase, one Integer and one special character'),
];

exports.addRecruiter = [
    body('name').notEmpty().withMessage('name is required').isLength({ min: 3, max: 50 })
        .withMessage('name must be minimum 3 chars and maximum 50 chars')
        .matches(/^[a-zA-Z ]+$/)
        .withMessage('name must contain alphabets and spaces and not symbol and special characters.')
        .trim(),
    body('email').notEmpty().withMessage('email is required').isLength({ min: 10, max: 50 })
        .withMessage('email must be minimum 10 chars and maximum 50 chars').isEmail().trim(),
    body('password').notEmpty().withMessage('password is required').isLength({ min: 8, max: 20 })
        .withMessage('password must be minimum 8 chars and maximum 20 chars.')
        .trim()
        .matches(/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/)
        .withMessage('password must contain one upperCase, one lowerCase, one Integer and one special character'),
    body('role_id').notEmpty().withMessage('role_id must be specified.').trim()
];