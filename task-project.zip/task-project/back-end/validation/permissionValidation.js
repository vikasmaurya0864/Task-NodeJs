const { body } = require('express-validator');


// create-permission
exports.createPermission = [
    body('method').notEmpty().withMessage('method must be specified.')
        .isLength({ min: 3, max: 8 })
        .withMessage("method must be minimum 3 chars & maximum 8 chars.")
        .trim(),
    // body('url').notEmpty().withMessage('url must be specified.')
    //     .isLength({ min: 8, max: 30 })
    //     .withMessage("url must be minimum 8 chars & maximum 30 chars.")
    //     .trim(),
    body('path').notEmpty().withMessage('path must be specified.')
        .isLength({ min: 8, max: 30 })
        .withMessage("path must be minimum 8 chars & maximum 30 chars.")
        .trim(),
    body('baseUrl').notEmpty().withMessage('baseUrl must be specified.')
        .isLength({ min: 1, max: 30 })
        .withMessage("baseUrl must be minimum 5 chars & maximum 30 chars.")
        .trim(),
];
