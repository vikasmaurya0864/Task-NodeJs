const { body, param } = require('express-validator');


// create-role
exports.createRole = [
    body('role_name').notEmpty().withMessage('role-name must be specified.')
    .isLength({ min: 4, max: 10 })
    .withMessage("Role-name must be minimum 4 chars & maximum 10 chars.")
    .trim(),

];