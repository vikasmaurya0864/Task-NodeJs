require('custom-env').env(true);

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const swaggerUi = require('swagger-ui-express');
const swagger = require('./utils/swagger');

var indexRouter = require('./routes/authRoute');
var usersRouter = require('./routes/users');
const roleRouter = require('./routes/roleRoute');
const jobRouter = require('./routes/jobRoute');
const permissionRouter = require('./routes/permissionRoute');
const role_permissionRouter = require('./routes/roles_permissionRoute');
const user_jobsRouter = require('./routes/user_jobsRoute');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swagger.swaggerSpec));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/auth', indexRouter);
app.use('/api/users', usersRouter);
app.use('/api/role', roleRouter);
app.use('/api/job', jobRouter);
app.use('/api/permission', permissionRouter);
app.use('/api/role-permission', role_permissionRouter);
app.use('/api/user-jobs', user_jobsRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
