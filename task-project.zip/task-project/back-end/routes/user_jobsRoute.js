var express = require('express');
var router = express.Router();
const validation = require('../validation/user_jobsValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/user_jobsController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');
/* GET home page. */

// create-user-jobs
router.post('/', validation.createUser_jobs, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.createUser_jobs));

router.get('/by-recruiter/:id', middleWare.verify, permission.permission, wrapper(controllers.getUser_jobs));// get jobs by recruiter
router.get('/by-candidate', middleWare.verify, permission.permission, wrapper(controllers.getByCandidate));// get applied jobs by candidate

// //update user-jobs
router.put('/:id', validation.createUser_jobs, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.updateUser_jobs));

// delete-user-jobs
router.delete('/:id', middleWare.verify, permission.permission, wrapper(controllers.deleteUser_jobs));

module.exports = router;
