var express = require('express');
var router = express.Router();
const validation = require('../validation/roleValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/roleController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');
/* GET home page. */

// create-role
router.post('/', validation.createRole, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.createRole));

router.get('/', middleWare.verify, permission.permission, wrapper(controllers.getRole));

// //update role
router.put('/:id', validation.createRole, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.updateRole));

// delete-role
router.delete('/:id', middleWare.verify, permission.permission, wrapper(controllers.deleteRole));

module.exports = router;
