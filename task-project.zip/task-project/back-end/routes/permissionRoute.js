var express = require('express');
var router = express.Router();
const validation = require('../validation/permissionValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/permissionController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');
/* GET home page. */

// create-permission
router.post('/', validation.createPermission, errorValidate.validateError, middleWare.verify,
    permission.permission, wrapper(controllers.createPermission));

router.get('/', middleWare.verify, permission.permission, wrapper(controllers.getPermission));

// //update permission
router.put('/:id', validation.createPermission, errorValidate.validateError, middleWare.verify,
    permission.permission, wrapper(controllers.updatePermission));

// delete-permission
router.delete('/:id', middleWare.verify, permission.permission, wrapper(controllers.deletePermission));

module.exports = router;
