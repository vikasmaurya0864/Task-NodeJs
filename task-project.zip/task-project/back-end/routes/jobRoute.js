var express = require('express');
var router = express.Router();
const validation = require('../validation/jobValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/jobController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');
/* GET home page. */

// create-job
router.post('/', validation.createJob, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.createJob));

router.get('/', middleWare.verify, permission.permission, wrapper(controllers.getJob));

// //update job
router.put('/:id', validation.createJob, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.updateJob));

// delete-job
router.delete('/:id', middleWare.verify, permission.permission, wrapper(controllers.deleteJob));

module.exports = router;
