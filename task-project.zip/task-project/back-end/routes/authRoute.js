var express = require('express');
var router = express.Router();
const validation = require('../validation/authValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/authController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
/* GET home page. */

//user-login
router.post('/login', validation.loginValidation, errorValidate.validateError, wrapper(controllers.login));

//forget-passwd enter email
router.post('/forgot-password', validation.verifyEmail, errorValidate.validateError, wrapper(controllers.forgotPassword));

//verify otp
router.post('/verify-otp/:id', validation.otp, errorValidate.validateError, wrapper(controllers.verifyOtp));

//update password
router.put('/update-password/:id', validation.checkPasswd, errorValidate.validateError, middleWare.verify, wrapper(controllers.resetPassword));

//logout-user
router.delete('/expire-session', middleWare.verify, wrapper(controllers.logOut));

module.exports = router;
