var express = require('express');
var router = express.Router();
const validation = require('../validation/userValidation');
const errorValidate = require('../utils/errorValidate');
const { wrapper } = require('../utils/errorWrapper');
const userController = require('../controllers/userController');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');

// admin controllers
const adminController = require('../controllers/adminController');



/* GET users listing. */
router.post('/', validation.createUser, errorValidate.validateError, wrapper(userController.createUsers));
//get All users
router.get('/', middleWare.verify, permission.permission, wrapper(userController.getAllUsers));
//get user-by-Id
router.get('/user-by-Id/:id', middleWare.verify, permission.permission, wrapper(userController.getUserById));

//update-user
router.put('/update-user/:id', middleWare.verify, permission.permission, wrapper(userController.updateUser));

//restore user-data
router.get('/restore-user/:id', middleWare.verify, permission.permission, wrapper(userController.restoreUser));
//delete user
router.delete('/delete-one-user/:id', middleWare.verify, permission.permission, wrapper(userController.deleteUser));

// add-recruiter
router.post('/add-recruiter', validation.addRecruiter, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(userController.createRecruiter));


////////////// admin Routes

router.get('/get-users/:id', middleWare.verify, permission.permission, wrapper(adminController.getUserList));
router.get('/get-jobs', middleWare.verify, permission.permission, wrapper(adminController.getJobs));
router.put('/update-recruiter/:id', middleWare.verify, permission.permission, wrapper(adminController.updateRecruiter));
router.get('/export-users/:id', middleWare.verify, permission.permission, wrapper(adminController.exportsUsers));
router.get('/export-candidates/:id', middleWare.verify, permission.permission, wrapper(adminController.exportCandidate));



module.exports = router;
