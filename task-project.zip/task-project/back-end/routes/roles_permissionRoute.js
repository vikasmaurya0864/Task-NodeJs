var express = require('express');
var router = express.Router();
const validation = require('../validation/roles_permissionValidation');
const errorValidate = require('../utils/errorValidate');
const controllers = require('../controllers/roles_permissionController');
const { wrapper } = require('../utils/errorWrapper');
const middleWare = require('../middleWare/checkAuth');
const permission = require('../middleWare/permission');
/* GET home page. */

// create-role_permission
router.post('/', validation.createRole_permission, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.createRoles_permission));

router.get('/', middleWare.verify, permission.permission, wrapper(controllers.getRoles_permission));

// //update role_permission
router.put('/:id', validation.createRole_permission, errorValidate.validateError, middleWare.verify, permission.permission, wrapper(controllers.updateRoles_permission));

// delete-role_permission
router.delete('/:id', middleWare.verify, permission.permission, wrapper(controllers.deleteRoles_permission));

module.exports = router;
