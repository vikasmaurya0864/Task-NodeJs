const jwt = require('jsonwebtoken');
const db = require('../models/index');

exports.verify = async (req, res, next) => {
    try {
        const bearer = req.header("Authorization");
        if (!bearer) {
            return res.status(401).send({ result: `please enter token or login.` })
        }
        else {
            const token = bearer.split(" ")[1];
            if (!token) {
                return res.status(401).send({ result: `please enter token or login.` })
            } else {
                const decode = jwt.verify(token, process.env.SECRET_KEY);
                if (decode) {
                    const find = await db.userToken.findOne({ where: { token: token } });
                    if (!find) {
                        return res.status(401).send({ result: `please enter token or login.` });
                    } else {
                        req.userDetails = decode;
                        next()
                    }
                }
                if (!decode) {
                    return res.status(401).send({ result: `not a valid token.` })
                }
            }
        }


    } catch (error) {
        return res.status(500).send({ result: `${error}` })
    }
}
