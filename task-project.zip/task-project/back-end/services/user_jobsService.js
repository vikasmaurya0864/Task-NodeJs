const db = require('../models/index');
const sendMail = require('../utils/email');
const redis = require('../utils/redis');


exports.createUser_jobs = async (data) => {
    let jobId = data.job_id;
    const response = await db.user_jobs.create(data);

    const job = await db.jobs.findOne({
        where: { id: jobId },
        attributes: ['recruiter_id', 'title']
    });
    const user = await db.users.findOne({
        where: { id: job.dataValues.recruiter_id },
        attributes: ['email', 'name']
    });

    const subject = `Job appiled`
    const text = `Hii ${data.name} This is to notify you that a new job has been applied
    for ${job.dataValues.title}.`
    // sendMail.sendEmail(data.email, subject, text);
    // -----------------------------------------------------------------------------------------
    const recruiter_subject = `Job appiled`
    const recruiter_text = `Hii ${user.dataValues.name} This is to notify you that a new job has been applied
    for ${job.dataValues.title}.`
    // sendMail.sendEmail(data.email, recruiter_subject, recruiter_text);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `permission cannot be added.` })
    }
}

exports.getUser_jobs = async (jobId, offset, limit) => {
    const res = redis.get('user-jobs-by-recruiter');
    if (res) {
        let data = JSON.parse(res);
        return ({ result: data });
    }
    const response = await db.user_jobs.findAll({ where: { job_id: jobId }, order: [['createdAt', 'DESC']], }, { limit: (limit) || 10, offset: (limit * (offset - 1)) || 0 });
    let a = JSON.stringify(response);
    let resp = redis.setEx('user-jobs-by-recruiter', 50000, a);
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find any permission.` })
    }
}

exports.getByCandidate = async (userId, offset, limit) => {
    const res = await redis.get('user_jobs');
    if (res) {
        let data = JSON.parse(res);
        return ({ result: data });
    }
    const response = await db.user_jobs.findAll({ where: { user_id: userId } }, { limit: (limit) || 10, offset: (limit * (offset - 1)) || 0 }, { attributes: ['title'] }, { order: [['createdAt', 'DESC']], });
    let a = JSON.stringify(response);
    let resp = redis.setEx('user_jobs', 50000, a);
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find any job.` })
    }
}

exports.updateUser_jobs = async (permissionId, data) => {
    const response = await db.user_jobs.update(data, { where: { id: permissionId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  permission.` })
    }
}

exports.deleteUser_jobs = async (permissionId) => {
    const response = await db.user_jobs.destroy({ where: { id: permissionId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}