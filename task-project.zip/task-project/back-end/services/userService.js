const db = require('../models/index');
const client = require('../utils/redis');
const bcrypt = require('bcrypt');

//creating a new user data.
exports.createUser = async (data) => {
    const salt = await bcrypt.genSalt(10);
    data.password = await bcrypt.hash(data.password, salt);
    const response = await db.users.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `data cannot be added.` })
    }
}

//get all users list
exports.findAllUsers = async () => {
    // const find = await client.get('find-all-users');
    // if (find) {
    //     return ({ result: find });
    // }
    const response = await db.users.findAll({ where: { deletedAt: null } });
    const store = await client.set('find-all-users', response);
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find users` })
    }
}

//getting user by id.
exports.getUserById = async (id) => {
    const find = await client.get('find-user-by-id');
    if (find) {
        let data = JSON.parse(find);
        return ({ result: data })
    }
    const response = await db.users.findOne({
        where: {
            [Op.and]: [
                { id: id },
                { deletedAt: null }
            ]
        }
    });
    let data = JSON.stringify(response);
    const store = await client.set('find-user-by-id', data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `unable to find details with given userId.` })
    }
}

//updating user data 
exports.updateOneUser = async (userId, data) => {
    if (data.password) {
        const salt = await bcrypt.genSalt(10);
        data.password = await bcrypt.hash(data.password, salt);
    }
    const response = await db.users.update(data, { where: { id: userId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `unable to upload user details please try again.` })
    }
}

//restoring user 
exports.restoreUserData = async (userId) => {
    const find = await client.get('restore-user-by-id');
    if (find) {
        return ({ result: find })
    }
    const response = await db.users.restore({ where: { id: userId } });
    const store = await client.set('restore-user-by-id', response);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot restore user.` })
    }
}

//deleteing user data 
exports.deleteUserData = async (userId) => {
    const response = await db.users.destroy({ where: { id: userId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `unable to delete record from database.` })
    }
}

exports.createRecruiter = async (data) => {
    const response = await db.users.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `unable to add recruiter.` })
    }
}