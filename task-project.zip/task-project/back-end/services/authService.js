const db = require('../models/index');
const client = require('../utils/redis');

const users = db.users;
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Op } = require('sequelize');



//user login 
exports.userLogin = async (email, password) => {
    if (email && password) {
        const find = await users.findOne({ where: { email: email } });
        if (find) {
            const decode = await bcrypt.compare(password, find.password);
            if (decode) {
                const data = {
                    user_name: find.name,
                    user_id: find.id,
                    email: find.email,
                    role_id: find.role_id
                }
                const signature = jwt.sign(data, process.env.SECRET_KEY, { expiresIn: "24h" })
                const user = {
                    user_id: find.id,
                    token: signature
                }
                const token = await db.userToken.findOne({ where: { user_id: find.id } });
                if (token) {
                    const user = {
                        user_id: find.id,
                        token: signature
                    }
                    const updateToken = await db.userToken.update(user, { where: { user_id: find.id } });
                }
                else {
                    const add = await db.userToken.create(user);
                }
                return ({ token: signature })
            }
            else {
                return ({ message: `password do not match` })
            }
        }
        else {
            return ({ message: `email doesn't exist in our records` })
        }
    }
    else {
        return ({ message: `please enter valid email & password` })
    }
}

//forget password
exports.forgetPassword = async (email) => {
    const response = await users.findOne({ where: { email: email } });
    if (response) {
        const generateOtp = (Math.floor(Math.random() * 9000) + 1000).toString();
        const res = await users.update({ otp: generateOtp }, { where: { email: email } });
        return ({ result: generateOtp, userId: response["id"] })
    }
    else {
        return ({ message: `user not exists.` })
    }
}

//verify otp 
exports.verifyOtp = async (id, otp) => {
    const response = await users.findOne({ where: { [Op.and]: [{ id: id }, { otp: otp }] } });
    if (response) {
        let condition = true;
        return ({ result: condition, msg: `otp verified.` })
    }
    else {
        return ({ message: `otp not matched please enter valid otp.` })
    }
}

exports.resetUserPasswd = async (userId, password, confirmPassword) => {
    if (password === confirmPassword) {
        const salt = await bcrypt.genSalt(10);
        password = await bcrypt.hash(password, salt);
        const response = await users.update({ password: password }, { where: { id: userId } });
        if (response) {
            return ({ result: response })
        }
        else {
            return ({ message: `cannot update password` })
        }
    }
    else {
        return ({ message: `password and newPassword do not match.` })
    }
}

exports.user_logOut = async (userId, token) => {
    const bearer = token.split(" ")[1];
    if (bearer) {
        const deleteToken = await db.userToken.destroy({ where: { [Op.and]: [{ user_id: userId }, { token: bearer }] } });
        if (deleteToken) {
            return ({ result: 'token deleted', data: deleteToken })
        }
        else {
            return ({ message: `could not delete token` })
        }
    }
    else {
        return ({ message: `could not verify token` })
    }
}