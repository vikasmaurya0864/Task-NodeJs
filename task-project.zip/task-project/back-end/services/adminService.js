const db = require('../models/index');
const redis = require('../utils/redis');
const Excel = require('exceljs');
const path = require('path');
const { Op } = require('sequelize');


exports.getCandidate = async (roleId, offset, limit) => {
    const res = await redis.get('find-candidate');
    if (res) {
        let data = JSON.parse(res);
        return ({ result: data });
    }
    const response = await db.users.findAll({ where: { role_id: roleId } }, { limit: (limit) || 10, offset: (limit * (offset - 1)) || 0 });
    let test = JSON.stringify(response);
    const resp = redis.setEx('find-candidate', 50000, test);
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `no user found.` })
    }
}
exports.getJob = async (offset, limit) => {
    const response = await db.jobs.findAll({ limit: (limit) || 10, offset: (limit * (offset - 1)) || 0 });
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `no jobs found.` })
    }
}

exports.updateRecruiter = async (userId, data) => {
    const response = await db.users.update(data, { where: { id: userId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `no jobs found.` })
    }
}

exports.exportUser = async (userId) => {
    const response = await db.users.findAll({ where: { role_id: userId } });
    if (response && response.length) {
        const workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet('Data');
        worksheet.columns = [
            { header: 'id', key: 'id', width: 20 },
            { header: 'name', key: 'name', width: 20 },
            { header: 'email', key: 'email', width: 20 }
        ];
        response.forEach((row) => {
            worksheet.addRow({
                id: row.id,
                name: row.name,
                email: row.email
            });
        });
        let dir = path.join(__dirname, '../public/uploads');
        workbook.xlsx.writeFile(`${dir}/${new Date().toLocaleString()}data.xlsx`)
            .then(() => {
                console.log('Excel file created!');
            })
            .catch((error) => {
                console.error(error);
            });
        return ({ result: `${dir}/${new Date()}data.xlsx` })
    }
    else {
        return ({ message: `no user found.` })
    }
}

exports.exportCandidate = async (userId) => {
    let arr = [];
    let details = [];
    const data = await db.user_jobs.findAll({
        attributes: ['user_id']
    });
    for (let i = 0; i < data.length; i++) {
        arr.push(data[i].dataValues.user_id);
    }
    const response = await db.users.findAll({
        where: { id: (arr) },
        include: [
            {
                model: db.jobs,
                through: 'user_jobs',
                attributes: ['title']
            }
        ]


    });
    let resp = {};
    for (let i = 0; i < response.length; i++) {
        resp["user_id"] = response[i]["id"];
        resp["name"] = response[i]["name"];
        resp["email"] = response[i]["email"];
        resp['techStack'] = response[i]['jobs'][i]['title'];
        details.push(resp);

    }
    if (response && response.length && details) {
        const workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet('Data');
        worksheet.columns = [
            { header: 'user_id', key: 'user_id', width: 20 },
            { header: 'name', key: 'name', width: 20 },
            { header: 'email', key: 'email', width: 20 },
            { header: 'techStack', key: 'techStack', width: 20 }
        ];
        details.forEach((row) => {
            worksheet.addRow({
                user_id: row.user_id,
                name: row.name,
                email: row.email,
                techStack: row.techStack
            });
        });
        let dir = path.join(__dirname, '../public/uploads');
        workbook.xlsx.writeFile(`${dir}/${new Date()}data.xlsx`)
            .then(() => {
                console.log('Excel file created!');
            })
            .catch((error) => {
                return ({ messsage: `${error}` })
            });
        return ({ result: `${dir}/${new Date()}data.xlsx` })
    }
    else {
        return ({ message: `no user found.` })
    }
}