const db = require('../models/index');

exports.createRoles_permission = async (data) => {
    const response = await db.roles_permission.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `permission cannot be added.` })
    }
}

exports.getRoles_permission = async () => {
    const response = await db.roles_permission.find();
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find any role.` })
    }
}

exports.updateRoles_permission = async (roleId, data) => {
    const response = await db.roles_permission.update(data, { where: { id: roleId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}

exports.deleteRoles_permission = async (roleId) => {
    const response = await db.roles_permission.destroy({ where: { id: roleId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}