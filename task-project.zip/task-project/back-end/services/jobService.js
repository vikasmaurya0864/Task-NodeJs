const db = require('../models/index');

exports.createJob = async (data) => {
    const response = await db.jobs.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `job cannot be added.` })
    }
}

exports.getJob = async (offset, limit) => {
    const response = await db.jobs.findAll({ order: [['createdAt', 'DESC']], }, { limit: (limit) || 10, offset: (limit * (offset - 1)) || 0 });
    if (response && response.length) {
        return ({ result: response })
    }
    else {
        return ({ message: `no jobs found.` })
    }
}

exports.updateJob = async (jobId, data) => {
    const response = await db.jobs.update(data, { where: { id: jobId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}

exports.deleteJob = async (jobId) => {
    const response = await db.jobs.destroy({ where: { id: jobId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}