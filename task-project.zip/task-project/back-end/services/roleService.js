const db = require('../models/index');
const redis = require('../utils/redis');

exports.createRole = async (data) => {
    const response = await db.roles.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `data cannot be added.` })
    }
}


exports.getRole = async () => {
    const data = redis.get('find-all-role');
    if (data) {
        let resp = JSON.parse(data);
        return ({ result: resp })
    }
    const response = await db.roles.findAll();
    if (response && response.length) {
        let red = JSON.stringify(response);
        let data = await redis.setEx('find-all-role', 50000, red)
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find any role.` })
    }
}

exports.updateRole = async (roleId, data) => {
    const response = await db.roles.update(data, { where: { id: roleId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}

exports.deleteRole = async (roleId) => {
    const response = await db.roles.destroy({ where: { id: roleId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}