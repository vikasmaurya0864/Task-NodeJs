const db = require('../models/index');

exports.createPermission = async (data) => {
    const response = await db.permission.create(data);
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `permission cannot be added.` })
    }
}

exports.getPermission = async () => {
    const response = await db.permission.find();
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot find any permission.` })
    }
}


exports.updatePermission = async (permissionId, data) => {
    const response = await db.permission.update(data, { where: { id: permissionId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  permission.` })
    }
}

exports.deletePermission = async (permissionId) => {
    const response = await db.permission.destroy({ where: { id: permissionId } });
    if (response) {
        return ({ result: response })
    }
    else {
        return ({ message: `cannot update  role.` })
    }
}