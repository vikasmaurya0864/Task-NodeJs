const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'smtp-mail.outlook.com',
    host: 'outlook.office365.com',
    port: 587,
    // secure: true,
    auth: {
        user: process.env.EMAIL,
        pass: process.env.PASSWORD,
    },
});

exports.sendEmail = (to, subject, text) => {
    const mailOptions = {
        from: 'vikasmaurya08642@outlook.com',
        to,
        subject,
        text,
    };

    transporter.sendMail(mailOptions, function (error, info) {
        try {
            if (error) {

                console.log(error);
            } else {
                console.log(`Email sent: ${info.response}`);
            }
        } catch (error) {
            throw new Error('something error occured' + error.message)
        }
    });
};
